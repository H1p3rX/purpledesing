<?php include 'includes/config.php' ;?>
<script>
window.location.href="<?php echo $web["link"] ;?>home";
</script>