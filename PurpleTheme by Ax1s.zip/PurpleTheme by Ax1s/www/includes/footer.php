<?php
echo '<div class="line"></div>';
echo '<footer class="mainfooter" role="contentinfo"> ';
echo '<div class="footer-bottom tblack"> ';
echo '<div class="container"> ';
echo '<div class="row"> ';
echo '<div class="col-xs-12"> ';
echo '<p class="text-xs-center">&copy; Copyright <a style="text-decoration:none;" href="index">'. $web["name"] .' '. date("Y") .'</a>  All rights reserved! Copying web content or its components is a criminal! <br /> Desing & code: <a style="text-decoration:none;" href="https://www.insites.sk/user/profile/1-ax1s">Denis "Ax1s" Mihál</a></p> ';
echo '</div> ';
echo '</div> ';
echo '</div> ';
echo '</div> ';
echo '</footer> ';

echo ' <script src="'. $web["link"] .'assets/js/jquery.js"></script> ';
echo ' <script src="'. $web["link"] .'assets/js/bootstrap.js"></script> ';
echo ' <script src="'. $web["link"] .'assets/js/bootstrap.min.js"></script> ';
echo ' <script src="'. $web["link"] .'assets/js/main.min.js"></script> ';
echo ' </body> ';
echo ' </html> ';
?>