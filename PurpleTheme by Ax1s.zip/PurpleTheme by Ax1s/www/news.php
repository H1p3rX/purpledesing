<?php
require_once 'includes/header.php';


echo ' <div class="container"> ';
echo ' <div style="margin-top: 10%;" class="row"> ';

echo ' <div class="col-md-12 "> ';
echo ' <h1 style="text-shadow: 2px 4px 10px #b000e6;">'. $web["name"] .' / '. ucfirst($page_name) .'</h1>';
echo ' </br>';
echo ' </br>';
echo ' </div>';



echo ' <div style="margin-top: 15px;" class="col-md-12 tblack-news lines"> ';
echo ' <h3 class="news-title"><font style="color:white;font-weight:bold;">>|</font>HTML5, CSS, JS Template<font style="color:white;font-weight:bold;">|<  #1</font></h3> ';
echo ' <div class="col-md-9"> ';
echo ' <p class="news-text">The new minecraft web template is a game design written in the programming language HTML5, CSS3, JS, PHP5.6 // The new minecraft web template is a game design  written in the programming language HTML5, CSS3, JS, PHP5.6<p> ';
echo ' </div> ';
echo ' <div class="news_owner hidden-xs"></div><h6 class="owne_name_news">Ax1s | 11.8</h6> ';
echo ' </div> ';



echo ' <div style="margin-top: 15px;" class="col-md-12 tblack-news lines"> ';
echo ' <h3 class="news-title"><font style="color:white;font-weight:bold;">>|</font>HTML5, CSS, JS Template<font style="color:white;font-weight:bold;">|<  #2</font></h3> ';
echo ' <div class="col-md-9"> ';
echo ' <p class="news-text">The new minecraft web template is a game design written in the programming language HTML5, CSS3, JS, PHP5.6 // The new minecraft web template is a game design  written in the programming language HTML5, CSS3, JS, PHP5.6<p> ';
echo ' </div> ';
echo ' <div class="news_owner hidden-xs"></div><h6 class="owne_name_news">Ax1s | 11.8</h6> ';
echo ' </div> ';



echo ' <div style="margin-top: 15px;" class="col-md-12 tblack-news lines"> ';
echo ' <h3 class="news-title"><font style="color:white;font-weight:bold;">>|</font>HTML5, CSS, JS Template<font style="color:white;font-weight:bold;">|<  #3</font></h3> ';
echo ' <div class="col-md-9"> ';
echo ' <p class="news-text">The new minecraft web template is a game design written in the programming language HTML5, CSS3, JS, PHP5.6 // The new minecraft web template is a game design  written in the programming language HTML5, CSS3, JS, PHP5.6<p> ';
echo ' </div> ';
echo ' <div class="news_owner hidden-xs"></div><h6 class="owne_name_news">Ax1s | 11.8</h6> ';
echo ' </div> ';



echo ' <div style="margin-top: 15px;" class="col-md-12 tblack-news lines"> ';
echo ' <h3 class="news-title"><font style="color:white;font-weight:bold;">>|</font>HTML5, CSS, JS Template<font style="color:white;font-weight:bold;">|<  #4</font></h3> ';
echo ' <div class="col-md-9"> ';
echo ' <p class="news-text">The new minecraft web template is a game design written in the programming language HTML5, CSS3, JS, PHP5.6 // The new minecraft web template is a game design  written in the programming language HTML5, CSS3, JS, PHP5.6<p> ';
echo ' </div> ';
echo ' <div class="news_owner hidden-xs"></div><h6 class="owne_name_news">Ax1s | 11.8</h6> ';
echo ' </div> ';


echo ' </div> ';
echo ' </div> ';

echo ' <div style="margin-top:15%;"></div> ';

require_once 'includes/footer.php';
?>