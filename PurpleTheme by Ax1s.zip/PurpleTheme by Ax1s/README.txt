Thank's for download this web site.

Instalation: 
1. Go to www/includes/config.php and rewrite all contact, links, name, banlist database.
2. And rewrite all website text to you text. :) 
3. All done. 

Banlist MySQL must set:
 > MySQL database must start on PUBLIC no LOCALHOST
 > MySQL must using version 5.7.22
 > Instalation:
   1. Go to file MaxBans/config.yml and scroll down
   2. Set you database login must by identic on the web site


/* Minecraft plugins */
File on Minecraft plugin is MaxBan 
 > Add to you minecraft server plugin maxbans.jar on this file.

Maxbans=> https://dev.bukkit.org/projects/maxbans

Bye end good using.